#!/bin/bash

echo "🚀 Preparando VozColectiva para deployment..."
echo ""

# Build project
echo "📦 Compilando proyecto..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Error en compilación"
    exit 1
fi

echo "✅ Build exitoso"
echo ""

# Show deployment info
echo "📋 Próximos pasos:"
echo ""
echo "OPCIÓN 1 - Netlify (Recomendado):"
echo "  1. Ve a https://netlify.com y crea una cuenta"
echo "  2. Arrastra la carpeta 'dist' al dashboard de Netlify"
echo "  3. ¡Listo! Obtendrás un URL público inmediatamente"
echo ""
echo "OPCIÓN 2 - Vercel:"
echo "  1. Ve a https://vercel.com y conecta tu GitHub"
echo "  2. Importa el repositorio"
echo "  3. Deploy automático"
echo ""
echo "OPCIÓN 3 - GitHub Pages:"
echo "  1. npm install --save-dev gh-pages"
echo "  2. npm run deploy"
echo ""
echo "OPCIÓN 4 - Surge.sh (Más rápido):"
echo "  1. npm install -g surge"
echo "  2. cd dist && surge"
echo ""
echo "📁 Archivos listos en: ./dist"
echo "🌐 Landing page lista en: ./public/index.html"
