import { useState, useEffect, useRef } from "react";

const R = "#D42B2B";
const RL = "#FDEAEA";

const WAVE = [3,5,8,6,9,7,10,8,7,9,6,8,5,7,9,8,6,5,8,7,9,6,8,10,7,5,8,6,9,7,5,8,6,9,7];
const REC_H = Array.from({length:35},(_,i)=>Math.round(25+Math.abs(Math.sin(i*0.6+1)*65)));

const Waveform = ({progress=0,height=36,color=R,light=false}) => (
  <div style={{display:"flex",alignItems:"center",gap:2.5,height}}>
    {WAVE.map((h,i)=>(
      <div key={i} style={{width:3,height:`${(h/10)*100}%`,background:i/WAVE.length<=progress?color:light?"rgba(255,255,255,0.35)":"#E0E0E0",borderRadius:2,flexShrink:0,transition:"all 0.3s ease"}} />
    ))}
  </div>
);

const Tag = ({label,selected,onClick})=>(
  <span onClick={onClick} style={{display:"inline-block",padding:"4px 10px",borderRadius:20,fontSize:12,fontWeight:500,cursor:onClick?"pointer":"default",background:selected?R:"#F0F0F0",color:selected?"#fff":"#555",whiteSpace:"nowrap",flexShrink:0,transition:"all 0.2s ease"}}>
    {label}
  </span>
);

const Avatar = ({initials,size=40,bg=R,fg="#fff"})=>(
  <div style={{width:size,height:size,borderRadius:"50%",background:bg,display:"flex",alignItems:"center",justifyContent:"center",color:fg,fontWeight:700,fontSize:size*0.34,flexShrink:0}}>
    {initials}
  </div>
);

const Btn = ({onClick,style:s,children,title})=>(
  <button onClick={onClick} title={title} style={{border:"none",cursor:"pointer",transition:"all 0.2s ease",...s}}>{children}</button>
);

// SVG icons
const Ico = ({d,size=22,fill="none",stroke="currentColor",sw=2})=>(
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={stroke} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
    <path d={d}/>
  </svg>
);
const IcoBack = ()=><Ico d="M15 18l-6-6 6-6"/>;
const IcoMore = ()=><svg width={20} height={20} viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/><circle cx="5" cy="12" r="1.5"/></svg>;
const IcoBell = ()=><Ico d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/>;
const IcoSearch = ()=><svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
const IcoPlay = ({s=20})=><svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>;
const IcoPause = ({s=24})=><svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>;
const IcoSkipB = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="currentColor"><polygon points="19 20 9 12 19 4 19 20"/><rect x="5" y="4" width="2" height="16" rx="1"/></svg>;
const IcoSkipF = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="currentColor"><polygon points="5 4 15 12 5 20 5 4"/><rect x="17" y="4" width="2" height="16" rx="1"/></svg>;
const IcoHeart = ({filled=false})=><svg width={20} height={20} viewBox="0 0 24 24" fill={filled?"currentColor":"none"} stroke="currentColor" strokeWidth={2}><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>;
const IcoShare = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>;
const IcoMsg = ()=><Ico d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>;
const IcoSmile = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>;
const IcoBkm = ()=><Ico d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" size={18}/>;
const IcoPhones = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke={R} strokeWidth={2}><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>;
const IcoHome = ({active})=><svg width={22} height={22} viewBox="0 0 24 24" fill={active?"currentColor":"none"} stroke="currentColor" strokeWidth={2}><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;
const IcoBook = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>;
const IcoUser = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>;
const IcoCompass = ()=><svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>;
const IcoCheck = ()=><svg width={36} height={36} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3} strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>;
const IcoMic = ()=><svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2.5}><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v4M8 23h8"/></svg>;
const IcoCopy = ()=><svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>;

const STORIES = [
  {id:1,initials:"AG",name:"Ana García",role:"Estudiante",rC:"#3B82F6",rB:"#EFF6FF",title:"Mi camino con la ansiedad",sub:"Historia de estudiante",dur:"4:32",likes:127,coms:84},
  {id:2,initials:"CM",name:"Prof. Carlos M.",role:"Docente",rC:"#D97706",rB:"#FFFBEB",title:"Rompiendo el estigma",sub:"Perspectiva docente",dur:"6:15",likes:345,coms:210},
  {id:3,initials:"LP",name:"Laura P.",role:"Estudiante",rC:"#3B82F6",rB:"#EFF6FF",title:"Aprendiendo a pedir ayuda",sub:"Historia personal",dur:"3:48",likes:89,coms:42},
];

const FILTER_TAGS = ["Todo","#Ansiedad","#Docentes","#Estrés","#Bienestar"];
const PUB_TAGS = ["#EstrésExámenes","#Ansiedad","#ApoyoDocente","#Bienestar","#AutoCuidado","#SaludMental"];
const REC_TAGS = ["#Ansiedad","#Apoyo","#Bienestar","#Docentes","#SaludMental"];

function FeedScreen({nav}){
  const [tag,setTag]=useState("Todo");
  return(
    <div style={{flex:1,overflowY:"auto"}}>
      <div style={{padding:"14px 18px 10px"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}>
            <div style={{width:36,height:36,borderRadius:"50%",background:RL,display:"flex",alignItems:"center",justifyContent:"center"}}>
              <IcoPhones/>
            </div>
            <div>
              <div style={{fontWeight:700,fontSize:17,color:"#111"}}>VozColectiva</div>
              <div style={{fontSize:12,color:"#999"}}>Hola, Ana 👋</div>
            </div>
          </div>
          <Btn style={{background:"none",padding:4,color:"#555"}}><IcoBell/></Btn>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8,background:"#F5F5F5",borderRadius:12,padding:"10px 14px",marginBottom:12}}>
          <IcoSearch/><span style={{color:"#BBB",fontSize:14}}>Buscar historias...</span>
        </div>
        <div style={{display:"flex",gap:8,overflowX:"auto",paddingBottom:4,marginBottom:18}}>
          {FILTER_TAGS.map(t=><Tag key={t} label={t} selected={tag===t} onClick={()=>setTag(t)}/>)}
        </div>
        <div onClick={()=>nav("player")} style={{background:R,borderRadius:18,padding:"18px 18px 16px",marginBottom:20,cursor:"pointer",transition:"transform 0.2s ease,box-shadow 0.2s ease",boxShadow:"0 4px 12px rgba(212,43,43,0.2)"}} onMouseEnter={e=>Object.assign(e.currentTarget.style,{transform:"translateY(-2px)",boxShadow:"0 8px 20px rgba(212,43,43,0.3)"})} onMouseLeave={e=>Object.assign(e.currentTarget.style,{transform:"translateY(0)",boxShadow:"0 4px 12px rgba(212,43,43,0.2)"})}>
          <div style={{fontSize:11,color:"rgba(255,255,255,0.65)",fontWeight:700,letterSpacing:1.2,marginBottom:8}}>DESTACADO</div>
          <div style={{color:"#fff",fontWeight:700,fontSize:17,lineHeight:1.3,marginBottom:4}}>
            "Hablar de salud mental fue lo que me salvó"
          </div>
          <div style={{color:"rgba(255,255,255,0.7)",fontSize:13,marginBottom:14}}>Prof. María Rodríguez · 8:20 min</div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{flex:1}}><Waveform progress={0.38} height={28} color="rgba(255,255,255,0.55)" light/></div>
            <div style={{width:38,height:38,borderRadius:"50%",background:"#fff",display:"flex",alignItems:"center",justifyContent:"center",color:R,flexShrink:0}}>
              <IcoPlay s={16}/>
            </div>
          </div>
        </div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <span style={{fontWeight:700,fontSize:15,color:"#111"}}>Historias recientes</span>
          <span style={{color:R,fontSize:13,fontWeight:500}}>Ver todo</span>
        </div>
        {STORIES.map(s=>(
          <div key={s.id} onClick={()=>nav("player")} style={{background:"#fff",borderRadius:14,padding:"14px 14px 12px",marginBottom:12,border:"1px solid #F0F0F0",cursor:"pointer",transition:"all 0.2s ease"}} onMouseEnter={e=>Object.assign(e.currentTarget.style,{boxShadow:"0 4px 12px rgba(0,0,0,0.08)",transform:"translateY(-1px)"})} onMouseLeave={e=>Object.assign(e.currentTarget.style,{boxShadow:"none",transform:"translateY(0)"})}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
              <Avatar initials={s.initials} size={38} bg={s.rB} fg={s.rC}/>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                  <span style={{fontWeight:600,fontSize:14,color:"#111"}}>{s.name}</span>
                  <span style={{fontSize:11,color:s.rC,background:s.rB,padding:"2px 8px",borderRadius:20,fontWeight:600}}>{s.role}</span>
                </div>
                <div style={{color:"#999",fontSize:12}}>{s.sub} · {s.dur}</div>
              </div>
              <Btn style={{background:"none",color:"#CCC",padding:2}}><IcoMore/></Btn>
            </div>
            <Waveform progress={0} height={22}/>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:10}}>
              <div style={{display:"flex",gap:14}}>
                <span style={{fontSize:13,color:"#999",display:"flex",alignItems:"center",gap:4}}><span style={{color:R}}>♥</span>{s.likes}</span>
                <span style={{fontSize:13,color:"#999",display:"flex",alignItems:"center",gap:4}}>💬 {s.coms}</span>
              </div>
              <div style={{width:32,height:32,borderRadius:"50%",background:R,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#fff"}}>
                <IcoPlay s={14}/>
              </div>
            </div>
          </div>
        ))}
        <div style={{height:8}}/>
      </div>
    </div>
  );
}

function RecordingScreen({nav}){
  const [rec,setRec]=useState(false);
  const [secs,setSecs]=useState(0);
  const [tags,setTags]=useState(["#Ansiedad","#Apoyo","#Bienestar"]);
  const ref=useRef();
  useEffect(()=>{
    if(rec) ref.current=setInterval(()=>setSecs(s=>s+1),1000);
    else clearInterval(ref.current);
    return()=>clearInterval(ref.current);
  },[rec]);
  const fmt=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
  const toggle=t=>setTags(p=>p.includes(t)?p.filter(x=>x!==t):[...p,t]);
  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",padding:"0 20px"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 0 18px"}}>
        <Btn onClick={()=>nav("feed")} style={{background:"#F5F5F5",borderRadius:"50%",width:36,height:36,display:"flex",alignItems:"center",justifyContent:"center",color:"#444"}}>
          <IcoBack/>
        </Btn>
        <span style={{fontWeight:600,fontSize:16}}>Nueva Historia</span>
        <Btn onClick={()=>nav("feed")} style={{background:"none",fontSize:22,color:"#AAA",lineHeight:1}}>×</Btn>
      </div>
      <div style={{background:"#F8F8F8",borderRadius:14,padding:"14px 16px",marginBottom:22,textAlign:"center"}}>
        <div style={{color:"#AAA",fontSize:13,marginBottom:10}}>¿Sobre qué tema es tu historia?</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:6,justifyContent:"center"}}>
          {REC_TAGS.map(t=><Tag key={t} label={t} selected={tags.includes(t)} onClick={()=>toggle(t)}/>)}
        </div>
      </div>
      <div style={{textAlign:"center",marginBottom:18}}>
        <div style={{color:"#BBB",fontSize:14}}>Toca para compartir</div>
        <div style={{fontWeight:700,fontSize:17,color:"#111"}}>tu experiencia</div>
      </div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:3,height:64,marginBottom:16}}>
        {REC_H.map((h,i)=>(
          <div key={i} style={{
            width:3,borderRadius:2,background:R,
            height:`${h}%`,opacity:rec?1:0.45,
            animation:rec?`rv${i%5} ${0.35+i%7*0.07}s ease-in-out infinite alternate`:"none",
          }}/>
        ))}
      </div>
      <div style={{textAlign:"center",fontSize:36,fontWeight:800,color:"#111",letterSpacing:2,marginBottom:28}}>
        {fmt(secs)}
      </div>
      <div style={{display:"flex",justifyContent:"center",marginBottom:20}}>
        <div style={{position:"relative"}}>
          {rec&&<div style={{position:"absolute",inset:-10,borderRadius:"50%",border:`2px solid ${R}`,opacity:0.3,animation:"rpulse 1.2s ease-in-out infinite"}}/>}
          {rec&&<div style={{position:"absolute",inset:-20,borderRadius:"50%",border:`2px solid ${R}`,opacity:0.15,animation:"rpulse 1.2s ease-in-out infinite 0.3s"}}/>}
          <Btn onClick={()=>setRec(!rec)} style={{width:72,height:72,borderRadius:"50%",background:R,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 8px 24px rgba(212,43,43,0.45)"}}>
            {rec
              ? <div style={{width:22,height:22,background:"#fff",borderRadius:4}}/>
              : <div style={{width:22,height:22,background:"#fff",borderRadius:"50%"}}/>
            }
          </Btn>
        </div>
      </div>
      {rec&&(
        <div style={{display:"flex",justifyContent:"center",gap:20,marginBottom:16}}>
          <Btn onClick={()=>setRec(false)} style={{background:"#F5F5F5",borderRadius:30,padding:"10px 20px",fontSize:14,fontWeight:600,color:"#444",display:"flex",alignItems:"center",gap:6}}>
            <IcoPause s={16}/> Pausar
          </Btn>
          <Btn onClick={()=>nav("publish")} style={{background:"#111",borderRadius:30,padding:"10px 20px",fontSize:14,fontWeight:600,color:"#fff",display:"flex",alignItems:"center",gap:6}}>
            ⏹ Terminar
          </Btn>
        </div>
      )}
      {!rec&&(
        <div style={{textAlign:"center",marginBottom:16}}>
          <Btn onClick={()=>nav("publish")} style={{background:"none",color:"#CCC",fontSize:13}}>→ ir a publicar (demo)</Btn>
        </div>
      )}
      <div style={{background:"#FFFBEA",borderRadius:12,padding:"12px 16px",textAlign:"center",marginTop:"auto",marginBottom:12}}>
        <span style={{fontSize:13,color:"#92752A",lineHeight:1.5}}>💛 Habla con calma. Tu historia puede ayudar a alguien más.</span>
      </div>
    </div>
  );
}

function PublishScreen({nav}){
  const [title,setTitle]=useState("Mi experiencia con el estrés");
  const [tags,setTags]=useState(["#EstrésExámenes","#Ansiedad"]);
  const [priv,setPriv]=useState("pub");
  const toggle=t=>setTags(p=>p.includes(t)?p.filter(x=>x!==t):[...p,t]);
  return(
    <div style={{flex:1,overflowY:"auto"}}>
      <div style={{display:"flex",alignItems:"center",gap:10,padding:"16px 18px 12px"}}>
        <Btn onClick={()=>nav("record")} style={{background:"#F5F5F5",borderRadius:"50%",width:36,height:36,display:"flex",alignItems:"center",justifyContent:"center",color:"#444"}}>
          <IcoBack/>
        </Btn>
        <span style={{fontWeight:700,fontSize:17}}>Publica tu historia</span>
      </div>
      <div style={{padding:"0 18px"}}>
        <div style={{border:"1px solid #EAEAEA",borderRadius:14,padding:"13px 14px",marginBottom:18,display:"flex",alignItems:"center",gap:12}}>
          <Btn style={{width:40,height:40,borderRadius:"50%",background:R,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <IcoPlay s={16}/>
          </Btn>
          <div style={{flex:1}}><Waveform progress={0} height={26}/></div>
          <span style={{fontSize:13,color:"#AAA",fontWeight:500,flexShrink:0}}>3:47</span>
        </div>
        <div style={{marginBottom:18}}>
          <label style={{fontSize:13,color:"#999",display:"block",marginBottom:6}}>Título de tu historia</label>
          <input value={title} onChange={e=>setTitle(e.target.value)} style={{width:"100%",border:"1.5px solid #E8E8E8",borderRadius:12,padding:"12px 14px",fontSize:15,outline:"none",fontFamily:"inherit",boxSizing:"border-box"}}/>
        </div>
        <div style={{marginBottom:18}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:10}}>
            <span style={{fontSize:16}}>🏷</span>
            <label style={{fontSize:13,color:"#999"}}>Etiquetas</label>
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
            {PUB_TAGS.map(t=><Tag key={t} label={t} selected={tags.includes(t)} onClick={()=>toggle(t)}/>)}
          </div>
        </div>
        <div style={{marginBottom:22}}>
          <label style={{fontSize:13,color:"#999",display:"block",marginBottom:10}}>Privacidad</label>
          <div style={{display:"flex",gap:12}}>
            {[{id:"pub",ico:"🌐",label:"Público",sub:"Toda la comunidad"},{id:"anon",ico:"👤",label:"Anónimo",sub:"Nombre oculto"}].map(o=>(
              <div key={o.id} onClick={()=>setPriv(o.id)} style={{flex:1,border:priv===o.id?`2px solid ${R}`:"1.5px solid #EAEAEA",borderRadius:14,padding:"14px 10px",cursor:"pointer",background:priv===o.id?RL:"#fff",textAlign:"center",transition:"all .2s"}}>
                <div style={{fontSize:22,marginBottom:4}}>{o.ico}</div>
                <div style={{fontWeight:700,fontSize:14,color:priv===o.id?R:"#333"}}>{o.label}</div>
                <div style={{fontSize:11,color:"#BBB"}}>{o.sub}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{fontSize:12,color:"#BBB",marginBottom:20,lineHeight:1.6}}>
          💙 Al compartir, aceptas nuestras <span style={{color:R,fontWeight:500}}>guías de comunidad</span>. Apoyamos un espacio seguro y empático para todos.
        </div>
        <Btn onClick={()=>nav("success")} style={{width:"100%",background:R,color:"#fff",borderRadius:16,padding:"16px 0",fontSize:16,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginBottom:24}}>
          <IcoMic/> Compartir Historia
        </Btn>
      </div>
    </div>
  );
}

function SuccessScreen({nav}){
  return(
    <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"0 36px",textAlign:"center",background:"#FAFAFA"}}>
      <div style={{width:88,height:88,borderRadius:"50%",background:R,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:28,boxShadow:"0 12px 36px rgba(212,43,43,0.3)"}}>
        <IcoCheck/>
      </div>
      <h2 style={{fontSize:24,fontWeight:800,color:"#111",marginBottom:12}}>¡Historia compartida!</h2>
      <p style={{color:"#999",fontSize:15,lineHeight:1.7,marginBottom:44}}>Tu voz puede marcar la diferencia. Gracias por compartir.</p>
      <Btn onClick={()=>nav("feed")} style={{background:R,color:"#fff",borderRadius:16,padding:"16px 48px",fontSize:16,fontWeight:700,boxShadow:"0 8px 24px rgba(212,43,43,0.3)"}}>
        Volver al inicio
      </Btn>
    </div>
  );
}

function PlayerScreen({nav}){
  const [playing,setPlaying]=useState(true);
  const [prog,setProg]=useState(0.38);
  const [liked,setLiked]=useState(false);
  const [comment,setComment]=useState("");
  const ref=useRef();
  useEffect(()=>{
    if(!playing){clearInterval(ref.current);return;}
    ref.current=setInterval(()=>setProg(p=>p>=1?0:+(p+0.0008).toFixed(4)),200);
    return()=>clearInterval(ref.current);
  },[playing]);
  const elapsed=Math.floor(prog*8*60);
  const fmt=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;
  const COMMENTS=[
    {initials:"ML",name:"Martina L.",role:"Estudiante",rC:"#3B82F6",rB:"#EFF6FF",time:"hace 2h",text:"Gracias por compartir esto. Me sentí muy identificada con tu historia 💙",likes:12},
    {initials:"RV",name:"Prof. Roberto V.",role:"Docente",rC:"#D97706",rB:"#FFFBEB",time:"hace 4h",text:"Es muy valiente hablar de esto. Los docentes también necesitamos estos espacios.",likes:28},
  ];
  return(
    <div style={{flex:1,overflowY:"auto"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 18px 12px"}}>
        <Btn onClick={()=>nav("feed")} style={{background:"#F5F5F5",borderRadius:"50%",width:36,height:36,display:"flex",alignItems:"center",justifyContent:"center",color:"#444"}}>
          <IcoBack/>
        </Btn>
        <span style={{fontWeight:600,fontSize:16}}>Reproduciendo</span>
        <Btn style={{background:"none",color:"#888"}}><IcoMore/></Btn>
      </div>
      <div style={{padding:"0 18px"}}>
        <div style={{background:R,borderRadius:20,padding:"30px 24px 22px",marginBottom:18,textAlign:"center",position:"relative"}}>
          <Avatar initials="MR" size={64} bg="rgba(255,255,255,0.2)" fg="#fff"/>
          <div style={{color:"#fff",fontWeight:700,fontSize:16,marginTop:10}}>Prof. María Rodríguez</div>
          <div style={{position:"absolute",bottom:14,right:16,display:"flex",gap:2,alignItems:"flex-end"}}>
            {[4,7,5,9,6,8,4].map((h,i)=>(
              <div key={i} style={{width:3,height:h*2,background:"rgba(255,255,255,0.5)",borderRadius:1,animation:playing?`rv${i%5} ${0.4+i*0.07}s ease-in-out infinite alternate`:"none"}}/>
            ))}
          </div>
        </div>
        <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:6}}>
          <div style={{flex:1,paddingRight:10}}>
            <div style={{fontWeight:700,fontSize:17,color:"#111",lineHeight:1.3,marginBottom:4}}>
              "Hablar de salud mental fue lo que me salvó"
            </div>
            <div style={{color:"#999",fontSize:13}}>Prof. María Rodríguez · Docente</div>
          </div>
          <Btn style={{background:"none",color:"#CCC",flexShrink:0,marginTop:2}}><IcoBkm/></Btn>
        </div>
        <div style={{display:"flex",gap:6,marginBottom:20}}>
          <Tag label="#SaludMental" selected/>
          <Tag label="#Docentes" selected/>
        </div>
        <Waveform progress={prog} height={44}/>
        <div style={{display:"flex",justifyContent:"space-between",color:"#CCC",fontSize:12,marginTop:6,marginBottom:22}}>
          <span>{fmt(elapsed)}</span><span>8:20</span>
        </div>
        <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:36,marginBottom:24}}>
          <Btn style={{background:"none",color:"#888"}}><IcoSkipB/></Btn>
          <Btn onClick={()=>setPlaying(!playing)} style={{width:62,height:62,borderRadius:"50%",background:R,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 8px 24px rgba(212,43,43,0.4)"}}>
            {playing?<IcoPause s={24}/>:<IcoPlay s={24}/>}
          </Btn>
          <Btn style={{background:"none",color:"#888"}}><IcoSkipF/></Btn>
        </div>
        <div style={{display:"flex",justifyContent:"space-around",borderTop:"1px solid #F2F2F2",borderBottom:"1px solid #F2F2F2",padding:"14px 0",marginBottom:20}}>
          {[
            {ico:<IcoHeart filled={liked}/>,lbl:liked?"Me gusta":"Me gusta",action:()=>setLiked(!liked)},
            {ico:<IcoSmile/>,lbl:"Abrazo"},
            {ico:<IcoMsg/>,lbl:"Comentar"},
            {ico:<IcoShare/>,lbl:"Compartir"}
          ].map(({ico,lbl,action})=>(
            <Btn key={lbl} onClick={action} style={{background:"none",color:"#888",display:"flex",flexDirection:"column",alignItems:"center",gap:4,transition:"color 0.2s ease"}} onMouseEnter={e=>e.currentTarget.style.color=R} onMouseLeave={e=>e.currentTarget.style.color="#888"}>
              {ico}<span style={{fontSize:12}}>{lbl}</span>
            </Btn>
          ))}
        </div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
          <span style={{fontWeight:700,fontSize:15,borderLeft:`3px solid ${R}`,paddingLeft:8,color:"#111"}}>Comentarios</span>
          <span style={{color:"#CCC",fontSize:13}}>{COMMENTS.length} comentarios</span>
        </div>
        {COMMENTS.map(c=>(
          <div key={c.name} style={{marginBottom:16}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
              <Avatar initials={c.initials} size={34} bg={c.rB} fg={c.rC}/>
              <div style={{flex:1}}>
                <span style={{fontWeight:700,fontSize:13,marginRight:6}}>{c.name}</span>
                <span style={{fontSize:11,color:c.rC,background:c.rB,padding:"2px 8px",borderRadius:20,fontWeight:600}}>{c.role}</span>
              </div>
              <span style={{fontSize:11,color:"#CCC",flexShrink:0}}>{c.time}</span>
            </div>
            <div style={{fontSize:13,color:"#555",lineHeight:1.6,marginBottom:4,paddingLeft:42}}>{c.text}</div>
            <div style={{fontSize:12,color:"#BBB",paddingLeft:42,display:"flex",alignItems:"center",gap:4}}><span style={{color:R}}>♥</span>{c.likes}</div>
          </div>
        ))}
        <div style={{display:"flex",gap:8,alignItems:"flex-end",marginBottom:24}}>
          <input placeholder="Escribe un comentario..." value={comment} onChange={e=>setComment(e.target.value)} style={{flex:1,border:"1.5px solid #E8E8E8",borderRadius:12,padding:"12px 14px",fontSize:14,outline:"none",fontFamily:"inherit",resize:"none",height:44}}/>
          <Btn style={{width:44,height:44,borderRadius:12,background:R,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <IcoMsg/>
          </Btn>
        </div>
      </div>
    </div>
  );
}

function BottomNav({onRecord}){
  return(
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-around",padding:"10px 0 14px",borderTop:"1px solid #F0F0F0",background:"#fff",flexShrink:0}}>
      {[
        {ico:<IcoHome active/>,lbl:"Inicio",active:true},
        {ico:<IcoCompass/>,lbl:"Explorar"},
        {mic:true},
        {ico:<IcoBook/>,lbl:"Biblioteca"},
        {ico:<IcoUser/>,lbl:"Perfil"},
      ].map((item,i)=>
        item.mic?(
          <Btn key="mic" onClick={onRecord} style={{width:54,height:54,borderRadius:"50%",background:R,display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 4px 16px rgba(212,43,43,0.45)",marginTop:-22}}>
            <IcoMic/>
          </Btn>
        ):(
          <Btn key={i} style={{background:"none",display:"flex",flexDirection:"column",alignItems:"center",gap:2,color:item.active?R:"#999",fontSize:11,fontWeight:item.active?700:400}}>
            {item.ico}{item.lbl}
          </Btn>
        )
      )}
    </div>
  );
}

export default function VozColectiva(){
  const [screen,setScreen]=useState("feed");
  const screens={
    feed:<FeedScreen nav={setScreen}/>,
    record:<RecordingScreen nav={setScreen}/>,
    publish:<PublishScreen nav={setScreen}/>,
    success:<SuccessScreen nav={setScreen}/>,
    player:<PlayerScreen nav={setScreen}/>,
  };
  return(
    <>
      <style>{`
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:#DCDCDC;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Display','Segoe UI',sans-serif;}
        ::-webkit-scrollbar{display:none;}
        @keyframes rpulse{0%,100%{transform:scale(1);opacity:.3}50%{transform:scale(1.18);opacity:.55}}
        @keyframes rv0{from{height:20%}to{height:82%}}
        @keyframes rv1{from{height:30%}to{height:90%}}
        @keyframes rv2{from{height:15%}to{height:72%}}
        @keyframes rv3{from{height:25%}to{height:88%}}
        @keyframes rv4{from{height:10%}to{height:78%}}
      `}</style>
      <div style={{minHeight:"100vh",background:"linear-gradient(135deg,#E8E8E8,#D0D0D0)",display:"flex",alignItems:"flex-start",justifyContent:"center",padding:"32px 16px",paddingBottom:60}}>
        <div style={{width:390,background:"#fff",borderRadius:44,boxShadow:"0 40px 80px rgba(0,0,0,0.22),0 0 0 1px rgba(0,0,0,0.08)",overflow:"hidden",display:"flex",flexDirection:"column",minHeight:790,position:"relative"}}>
          <div style={{padding:"14px 26px 4px",display:"flex",justifyContent:"space-between",alignItems:"center",flexShrink:0,background:"#fff"}}>
            <span style={{fontSize:13,fontWeight:600}}>9:41</span>
            <div style={{width:76,height:20,background:"#000",borderRadius:10}}/>
            <div style={{display:"flex",gap:5,alignItems:"center"}}>
              <svg width="16" height="12" viewBox="0 0 20 12" fill="#000"><rect x="0" y="5" width="3" height="7" rx="1"/><rect x="5" y="3" width="3" height="9" rx="1"/><rect x="10" y="1" width="3" height="11" rx="1"/><rect x="15" y="0" width="3" height="12" rx="1"/></svg>
              <svg width="22" height="12" viewBox="0 0 22 12" fill="#000"><rect width="18" height="12" rx="2"/><rect x="19" y="3" width="3" height="6" rx="1.5"/></svg>
            </div>
          </div>
          <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
            {screens[screen]}
          </div>
          {screen==="feed"&&<BottomNav onRecord={()=>setScreen("record")}/>}
          <div style={{display:"flex",justifyContent:"center",padding:"8px 0 12px",flexShrink:0,background:"#fff"}}>
            <div style={{width:120,height:5,background:"#000",borderRadius:3,opacity:.15}}/>
          </div>
        </div>
      </div>
    </>
  );
}
