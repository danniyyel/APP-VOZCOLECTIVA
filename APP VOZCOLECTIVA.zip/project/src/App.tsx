import VozColectiva from './VozColectiva';

function App() {
  return <VozColectiva />;
}

export default App;
