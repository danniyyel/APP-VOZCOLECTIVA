# Guía de Deployment - VozColectiva

Tu aplicación está lista para ser desplegada en línea. Aquí tienes varias opciones gratuitas y fáciles.

## Opción 1: Netlify (Recomendada - Más Fácil)

### Paso a Paso:

1. **Crear cuenta en Netlify**
   - Ve a https://netlify.com
   - Regístrate con GitHub, GitLab, o email

2. **Subir tu código a GitHub** (si no lo has hecho)
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/TU_USUARIO/vozcolectiva.git
   git push -u origin main
   ```

3. **Deployar en Netlify**
   - En Netlify, hacer clic en "New site from Git"
   - Conectar tu repositorio de GitHub
   - Configuración automática detectada:
     - Build command: `npm run build`
     - Publish directory: `dist`
   - Hacer clic en "Deploy site"

4. **¡Listo!**
   - Netlify te dará un URL como: `https://random-name.netlify.app`
   - Puedes cambiar el nombre en Site settings

**Ventajas de Netlify:**
- Deploy automático cada vez que haces push a GitHub
- HTTPS gratuito
- Muy rápido
- Fácil configuración de dominio personalizado

---

## Opción 2: Vercel (Excelente Alternativa)

### Paso a Paso:

1. **Crear cuenta en Vercel**
   - Ve a https://vercel.com
   - Regístrate con GitHub

2. **Importar proyecto**
   - En Vercel dashboard, hacer clic en "New Project"
   - Importar tu repositorio de GitHub
   - Vercel detecta automáticamente que es Vite

3. **Deployar**
   - Configuración automática:
     - Framework Preset: Vite
     - Build Command: `npm run build`
     - Output Directory: `dist`
   - Hacer clic en "Deploy"

4. **¡Listo!**
   - URL automático: `https://vozcolectiva.vercel.app`

---

## Opción 3: GitHub Pages (Gratis con GitHub)

### Paso a Paso:

1. **Instalar gh-pages**
   ```bash
   npm install --save-dev gh-pages
   ```

2. **Agregar scripts a package.json**
   ```json
   {
     "scripts": {
       "predeploy": "npm run build",
       "deploy": "gh-pages -d dist"
     }
   }
   ```

3. **Modificar vite.config.ts**
   ```typescript
   export default defineConfig({
     base: '/nombre-de-tu-repo/',
     // ... resto de configuración
   })
   ```

4. **Deployar**
   ```bash
   npm run deploy
   ```

5. **URL resultante**
   - `https://TU_USUARIO.github.io/nombre-de-tu-repo/`

---

## Opción 4: Surge.sh (Ultra Simple)

### Paso a Paso:

1. **Instalar Surge**
   ```bash
   npm install -g surge
   ```

2. **Build y Deploy**
   ```bash
   npm run build
   cd dist
   surge
   ```

3. **Elegir dominio**
   - Surge te pedirá crear un dominio como: `vozcolectiva.surge.sh`

---

## Estructura de URLs

Una vez deployado, tendrás:

### Landing Page Pública
```
https://tu-app.netlify.app/public/
```
- Página de bienvenida para compartir
- Sin necesidad de interacción
- Vista previa de la plataforma

### Aplicación Completa
```
https://tu-app.netlify.app/
```
- App interactiva completa
- Todas las funcionalidades
- Listo para usar

---

## Después del Deploy

### Verificar Funcionamiento
1. Visita tu URL principal
2. Prueba navegar entre pantallas
3. Verifica que los estilos carguen correctamente
4. Comparte el link de `/public/` para mostrar la landing

### Personalizar Dominio (Opcional)
- Netlify: Site settings > Domain management
- Vercel: Settings > Domains
- GitHub Pages: Repository settings > Pages

### Configurar Analytics (Opcional)
- Google Analytics
- Plausible Analytics
- Simple Analytics

---

## Troubleshooting

### Error: Página en blanco
- Verificar que `base: './'` esté en vite.config.ts
- Revisar consola del navegador por errores

### CSS no carga
- Verificar que los archivos de assets se generan en `dist/assets/`
- Confirmar que las rutas son relativas

### Build falla
- Ejecutar `npm install` antes de build
- Verificar versión de Node (usar Node 18+)
- Revisar errores en consola

---

## Datos de Ejemplo

La app actualmente usa datos de ejemplo:
- 3 historias de muestra en el feed
- 1 historia destacada
- Comentarios de ejemplo
- Formas de onda animadas pero simuladas

Para funcionalidad completa, necesitarías:
1. Configurar Supabase (base de datos)
2. Implementar autenticación
3. Conectar grabación real de audio
4. Persistir datos en la nube

---

## Compartir tu Prototipo

Una vez deployado, puedes compartir:

**Presentación Ejecutiva:**
- Link: `https://tu-app.netlify.app/public/`
- Muestra la propuesta de valor
- Diseño profesional
- Estadísticas de comunidad

**Demo Interactiva:**
- Link: `https://tu-app.netlify.app/`
- Funcionalidad completa
- Interacciones reales
- Listo para feedback de usuarios

---

## Costos

Todas las opciones son **GRATIS** para proyectos pequeños:
- Netlify: 100GB bandwidth/mes
- Vercel: 100GB bandwidth/mes
- GitHub Pages: 1GB storage, 100GB bandwidth/mes
- Surge: 200+ proyectos gratis

¡Perfecto para prototipos y demos!
