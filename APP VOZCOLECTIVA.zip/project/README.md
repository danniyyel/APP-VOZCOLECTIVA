# VozColectiva 🎙️

Plataforma de historias compartidas sobre salud mental en la comunidad educativa.

## Vista Rápida

**Demo en vivo:** Sigue las instrucciones de deploy abajo para obtener tu URL público.

## Características

- Diseño móvil-first inspirado en apps de podcasting
- Grabación de historias de audio (UI lista, funcionalidad simulada)
- Feed de historias con forma de onda visual
- Interacciones de apoyo (likes, comentarios, compartir)
- Landing page pública para compartir
- Responsive y accesible

## Deployment Express 🚀

### Netlify (Más fácil - 2 minutos)

1. Ve a [netlify.com](https://netlify.com) y regístrate
2. En el dashboard, arrastra la carpeta `dist/` al área de deploy
3. ¡Listo! Obtendrás un URL como `https://random-name.netlify.app`

**O con GitHub:**
1. Sube tu código a GitHub
2. En Netlify: "New site from Git" → selecciona tu repo
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Deploy automático cada push

### Vercel

1. Ve a [vercel.com](https://vercel.com)
2. "New Project" → importa tu repo de GitHub
3. Detecta automáticamente la configuración
4. Deploy con un clic

### Surge.sh (Ultra rápido)

```bash
npm install -g surge
npm run build
cd dist
surge
```

Elige un nombre como `vozcolectiva.surge.sh` y listo.

## Estructura de URLs

Una vez deployado tendrás:

| URL | Descripción |
|-----|-------------|
| `https://tu-app.netlify.app/` | App interactiva completa |
| `https://tu-app.netlify.app/public/` | Landing page pública |

## Desarrollo Local

```bash
# Instalar dependencias
npm install

# Servidor de desarrollo
npm run dev

# Build de producción
npm run build

# Preview de producción
npm run preview
```

## Deployment Guiado

```bash
# Ejecutar script de ayuda
./deploy.sh
```

Ver [`DEPLOY_GUIDE.md`](./DEPLOY_GUIDE.md) para instrucciones detalladas paso a paso.

## Mejoras Implementadas

- Landing page pública sin dependencias
- Transiciones suaves y hover effects
- Campo de comentarios funcional
- Botón "Me gusta" interactivo
- Metadatos optimizados para redes sociales
- Configuración lista para múltiples plataformas de deploy

Ver [`IMPROVEMENTS.md`](./IMPROVEMENTS.md) para lista completa.

## Tecnologías

- React 18 + TypeScript
- Vite (build tool)
- Tailwind CSS
- Supabase (preparado para backend)

## Próximos Pasos

Para funcionalidad completa:

1. **Configurar Supabase** - Base de datos en la nube
2. **Implementar autenticación** - Login de usuarios
3. **Grabación real de audio** - Web Audio API
4. **Persistencia de datos** - Guardar historias y comentarios

## Estructura del Proyecto

```
/
├── src/
│   ├── App.tsx              # Punto de entrada
│   ├── VozColectiva.jsx     # Componente principal
│   └── main.tsx             # Renderer
├── public/
│   └── index.html           # Landing page pública
├── dist/                    # Build de producción
├── netlify.toml             # Config Netlify
├── vercel.json              # Config Vercel
├── deploy.sh                # Script de ayuda
├── DEPLOY_GUIDE.md          # Guía detallada
└── IMPROVEMENTS.md          # Lista de mejoras
```

## Compartir el Prototipo

**Para stakeholders/equipo:**
- Comparte: `https://tu-app.netlify.app/public/`
- Muestra la visión del producto

**Para feedback de usuarios:**
- Comparte: `https://tu-app.netlify.app/`
- Permite interacción real con la UI

## Soporte

- [`DEPLOY_GUIDE.md`](./DEPLOY_GUIDE.md) - Guía completa de deployment
- [`IMPROVEMENTS.md`](./IMPROVEMENTS.md) - Detalles técnicos de mejoras
- Netlify docs: https://docs.netlify.com
- Vercel docs: https://vercel.com/docs

---

Hecho con React + Vite + Supabase
